USE academia;

INSERT INTO atividades (descricao) VALUES ('Mapeamento de Estrelas');
INSERT INTO atividades (descricao) VALUES ('Suporte ao Windows');
INSERT INTO atividades VALUES (DEFAULT, 'Suporte ao MacOS');

DELETE FROM atividades WHERE codigo = 8
;

UPDATE atividades 
SET descricao = 'Suporte ao MacOS antes do Mavericks'
WHERE codigo = 8
;

SELECT descricao FROM atividades;

SELECT *
FROM alunos
WHERE peso >= 78 
  AND altura > 1.80;


SELECT telefone, data_nascimento, peso, matricula 
FROM alunos;



